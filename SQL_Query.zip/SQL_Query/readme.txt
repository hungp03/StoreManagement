----------------------------------NOTICE--------------------------------
Nếu file SQLQuery_Main không hoạt động hoặc gây ra lỗi thì dùng 2 file 
còn lại và thực hiện tạo cơ sở dữ liệu
------------------------------------------------------------------------